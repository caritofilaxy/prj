package Meter::Appartments;

#===============================================================================
#     REVISION:  $Id: Appartments.pm 55 2011-07-12 14:39:44Z xdr.box@gmail.com $
#  DESCRIPTION:  Class::DBI wrapper for 'appartments' table
#===============================================================================

use strict;
use warnings;

use base qw(Meter::DBI);

use Readonly;
Readonly our $VERSION => qw($Revision: 55 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use Meter::Regexp qw(
    $NOT_EMPTY_RE
);

Readonly my $METER_NUMBER_RE => qr/\A\d+\z/xms;

sub init_table {
    my $class = shift;

    __PACKAGE__->set_up_table('appartments');

    __PACKAGE__->has_a( user_id  => 'Meter::Users' );
    __PACKAGE__->has_a( house_id => 'Meter::Houses' );
    __PACKAGE__->has_many(
        meterings => 'Meter::Meterings',
        { order_by => 'start_date DESC' }
    );

    __PACKAGE__->constrain_column( appartment_number => qr/\A[1-9]\d*\z/xms );
    __PACKAGE__->constrain_column( first_name        => $NOT_EMPTY_RE );
    __PACKAGE__->constrain_column( last_name         => $NOT_EMPTY_RE );
    __PACKAGE__->constrain_column(
        cold_water_meter_number => $METER_NUMBER_RE );
    __PACKAGE__->constrain_column(
        hot_water_meter_number => $METER_NUMBER_RE );

    return;
}

1;
