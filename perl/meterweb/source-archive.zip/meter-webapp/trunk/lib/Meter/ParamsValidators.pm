package Meter::ParamsValidators;

#===============================================================================
#     REVISION:  $Id: ParamsValidators.pm 37 2011-07-07 14:30:49Z xdr.box@gmail.com $
#  DESCRIPTION:  Commonly used params validators
#===============================================================================

use strict;
use warnings;

use base qw(Exporter);

use Readonly;
Readonly our $VERSION => qw($Revision: 37 $) [1];

use English qw( -no_match_vars );
use Params::Validate qw(:all);

#use Smart::Comments;

our @EXPORT_OK = qw(
    $VALIDATOR_UNSIGNED_INTEGER
    $VALIDATOR_NOT_EMPTY
);

Readonly our $VALIDATOR_UNSIGNED_INTEGER => {
    type  => SCALAR(),
    regex => qr/\A\d+\z/xms,
};

Readonly our $VALIDATOR_NOT_EMPTY => {
    type  => SCALAR(),
    regex => qr/\A.+\z/xms,
};

1;
