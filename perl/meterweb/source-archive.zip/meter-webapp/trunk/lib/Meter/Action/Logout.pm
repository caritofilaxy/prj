package Meter::Action::Logout;

#===============================================================================
#     REVISION:  $Id: Logout.pm 83 2011-07-18 08:56:07Z xdr.box@gmail.com $
#  DESCRIPTION:  Logout action
#===============================================================================

use strict;
use warnings;

use Readonly;
Readonly our $VERSION => qw($Revision: 83 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use Meter::Log;

use base qw(Meter::Action);

sub generate_page_content {
    my $self = shift;

    my $logger = get_logger();

    eval { $self->{'session'}->delete() };

    if ($EVAL_ERROR) {
        my $why = $EVAL_ERROR;
        $logger->error( 'Cannot delete session of user '
                . $self->{'user'}->username()
                . ": $why" );

        return $self->redirect_error(
            'Ошибка удаления сессии', 'welcome' );
    }

    $logger->info( 'User '
            . $self->{'user'}->username()
            . ' has been successfully logged out' );

    return $self->redirect_ok(
        'Выход из системы выполнен успешно',
        'welcome' );
}

1;
