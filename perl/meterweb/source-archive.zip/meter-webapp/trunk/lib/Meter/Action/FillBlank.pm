package Meter::Action::FillBlank;

#===============================================================================
#     REVISION:  $Id: FillBlank.pm 80 2011-07-15 17:37:09Z xdr.box@gmail.com $
#  DESCRIPTION:  Fill meterings blank
#===============================================================================

use strict;
use warnings;

use Readonly;
Readonly our $VERSION => qw($Revision: 80 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use Meter::Log;

use base qw(Meter::Action);

sub generate_page_content {
    my $self = shift;

    my $logger = get_logger();

    my $appartment = $self->{'user'}->appartment();
    my $metering
        = Meter::Meterings->retrieve( $self->{'params'}{'metering_id'} );

    if ( !$metering ) {
        $logger->error( 'Metering with ID '
                . $self->{'params'}{'metering_id'}
                . ' not found' );

        return $self->redirect_error(
            'Показания счётчиков не найдены',
            'show_meterings' );
    }

    if ( $metering->appartment()->user()->username() ne
        $self->{'user'}->username() )
    {
        $logger->error( 'User '
                . $self->{'user'}->username()
                . ' is trying to fill blank using metering of user '
                . $metering->appartment()->user()->username() );

        return $self->redirect_error(
            'Нельзя заполнить бланк с использованием '
                . 'показаний счётчиков других пользователей',
            'show_meterings'
        );
    }

    return $self->process_template(
        'fill_blank.tt2',
        {   hide_menu               => 1,
            address                 => $appartment->house()->address(),
            last_name               => $appartment->last_name(),
            first_name              => $appartment->first_name(),
            middle_name             => $appartment->middle_name(),
            appartment_number       => $appartment->appartment_number(),
            cold_water_meter_number => $appartment->cold_water_meter_number(),
            hot_water_meter_number  => $appartment->hot_water_meter_number(),
            start_date              => $metering->start_date(),
            end_date                => $metering->end_date(),
            cold_water_start_amount => $metering->cold_water_start_amount(),
            cold_water_end_amount   => $metering->cold_water_end_amount(),
            hot_water_start_amount  => $metering->hot_water_start_amount(),
            hot_water_end_amount    => $metering->hot_water_end_amount(),
            now                     => $self->now(),
        }
    );
}

1;
