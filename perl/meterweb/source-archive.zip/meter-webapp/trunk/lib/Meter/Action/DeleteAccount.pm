package Meter::Action::DeleteAccount;

#===============================================================================
#     REVISION:  $Id: DeleteAccount.pm 81 2011-07-18 08:48:06Z xdr.box@gmail.com $
#  DESCRIPTION:  Delete account
#===============================================================================

use strict;
use warnings;

use Readonly;
Readonly our $VERSION => qw($Revision: 81 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use Meter::Log;

use base qw(Meter::Action);

sub generate_page_content {
    my $self = shift;

    my $logger   = get_logger();
    my $username = $self->{'user'}->username();

    eval {
        $self->{'user'}->delete();    # deletes all user's stuff as well
    };

    if ($EVAL_ERROR) {
        my $why = $EVAL_ERROR;
        $logger->error("Cannot delete account of user $username: $why");

        return $self->redirect_error(
            'Ошибка удаления аккаунта', 'welcome' );
    }

    $logger->info(
        "Account of user '$username' has been successfully deleted");

    return $self->redirect_ok( 'Аккаунт успешно удалён',
        'welcome' );
}

1;
