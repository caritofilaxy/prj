package Meter::Action::Welcome;

#===============================================================================
#     REVISION:  $Id: Welcome.pm 71 2011-07-14 10:27:45Z xdr.box@gmail.com $
#  DESCRIPTION:  Welcome page
#===============================================================================

use strict;
use warnings;

use Readonly;
Readonly our $VERSION => qw($Revision: 71 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use base qw(Meter::Action);

sub is_auth_requied {
    my $self = shift;

    return 0;
}

1;
