package Meter::Action::Register;

#===============================================================================
#     REVISION:  $Id: Register.pm 88 2011-07-18 11:04:27Z xdr.box@gmail.com $
#  DESCRIPTION:  Register a new user
#===============================================================================

use strict;
use warnings;

use Readonly;
Readonly our $VERSION => qw($Revision: 88 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use Meter::Log;
use Meter::Users;

use base qw(Meter::Action);

sub is_auth_requied {
    my $self = shift;

    return 0;
}

sub generate_page_content {
    my $self = shift;

    my $logger = get_logger();

    if ( $self->is_user_logged_in() ) {
        $logger->warn( 'User '
                . $self->{'user'}->username()
                . ' already has registered account' );

        return $self->redirect_ok(
            'У вас уже есть зарегистрированный аккаунт',
            'welcome'
        );
    }

    if ( $ENV{'REQUEST_METHOD'} eq 'GET' ) {
        return $self->process_template( 'register.tt2', {} );
    }

    my $username       = $self->{'params'}{'username'};
    my $password       = $self->{'params'}{'password'};
    my $password_again = $self->{'params'}{'password_again'};

    if ( $password ne $password_again ) {
        $logger->warn("Password mismatch for user $username");

        return $self->redirect_error(
            'Ошибка регистрации аккаунта: пароли не совпадают',
            'register'
        );
    }

    $self->{'user'} = eval {
        Meter::Users->insert(
            {   username => $username,
                password => $password,
            }
        );
    };

    if ($EVAL_ERROR) {
        my $why = $EVAL_ERROR;
        $logger->error("Cannot register user $username: $why");

        return $self->redirect_error(
            'Ошибка регистрации аккаунта',
            'register', $why );
    }

    $logger->info( 'User '
            . $self->{'user'}->username()
            . ' has been successfully registered' );

    return $self->redirect_ok(
        'Регистрация в системе выполнена успешно',
        'login'
    );
}

sub get_error_regexes_list {
    my $self = shift;

    return [
        {   regex => qr/\Qusername is not unique\E/xms,
            message =>
                'пользователь с таким именем уже есть',
        },

        {   regex => qr/\Qpassword fails 'regexp' constraint\E/xms,
            message =>
                'пароль не соответствует установленному формату',
        },

        {   regex => qr/\Qusername fails 'regexp' constraint\E/xms,
            message =>
                'имя пользователя не соответствует установленному формату',
        },
    ];
}

1;
