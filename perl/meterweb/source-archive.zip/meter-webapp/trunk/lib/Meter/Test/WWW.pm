package Meter::Test::WWW;

#===============================================================================
#     REVISION:  $Id: WWW.pm 167 2011-09-21 11:31:32Z xdr.box@gmail.com $
#  DESCRIPTION:  Helper functions to simplify front-end (WWW) testing using
#                Test::WWW::Mechanize module
#===============================================================================

use strict;
use warnings;

use Readonly;
Readonly our $VERSION => qw($Revision: 167 $) [1];

use base qw(Exporter);
our @EXPORT_OK = qw(
    get_action_link_regex
    init_houses
    u8
    get_username
    get_password
    get_new_password
    get_house_address
    get_last_name
    get_first_name
    get_middle_name
    get_cold_water_meter_number
    get_hot_water_meter_number
    get_appartment_number
    get_cold_water_consumption
    get_hot_water_consumption
    get_metering_passing_day
    get_email
);

use English qw( -no_match_vars );
use Carp;
use Encode;

#use Smart::Comments;

use Meter::Houses;

Readonly my $USERNAME => 'user';
Readonly my $PASSWORD => 'password';

Readonly my $NUMBER_OF_HOUSES               => 5;
Readonly my $STREET_NAME                    => 'Улица Стекова';
Readonly my $LAST_NAME                      => 'Иванов';
Readonly my $FIRST_NAME                     => 'Иван';
Readonly my $MIDDLE_NAME                    => 'Иванович';
Readonly my $COLD_WATER_METER_NUMBER_PREFIX => 1;
Readonly my $HOT_WATER_METER_NUMBER_PREFIX  => 2;
Readonly my $COLD_WATER_AMOUNT_FACOR        => 2;
Readonly my $HOT_WATER_AMOUNT_FACOR         => 3;
Readonly my $METERING_PASSING_DAY           => 25;
Readonly my $EMAIL_DOMAIN                   => 'foobar.com';

sub init_houses {
    foreach my $house_number ( 1 .. $NUMBER_OF_HOUSES ) {
        Meter::Houses->insert(
            { address => "$STREET_NAME, д. $house_number" } );
    }

    return;
}

sub get_action_link_regex {
    my $action = shift;

    return qr/action=\Q$action\E\z/xms;
}

sub u8 {
    my $str = shift;

    return decode( 'utf-8', $str );
}

sub get_username {
    my $user_index = shift;

    return $USERNAME . $user_index;
}

sub get_password {
    my $user_index = shift;

    return $PASSWORD . $user_index;
}

sub get_new_password {
    my $user_index = shift;

    return get_password($user_index) . '-new';
}

sub get_house_address {
    my $user_index = shift;

    my $house_number = $user_index % $NUMBER_OF_HOUSES + 1;
    return "$STREET_NAME, д. $house_number";
}

sub get_last_name {
    my $user_index = shift;

    return $LAST_NAME . $user_index;
}

sub get_first_name {
    my $user_index = shift;

    return $FIRST_NAME . $user_index;
}

sub get_middle_name {
    my $user_index = shift;

    # even-numbered users have no middle name. Sorry
    return $user_index % 2 == 0 ? q{} : ( $MIDDLE_NAME . $user_index );
}

sub get_cold_water_meter_number {
    my $user_index = shift;

    ## no critic (ProhibitParensWithBuiltins)
    return sprintf( "$COLD_WATER_METER_NUMBER_PREFIX%05d", $user_index );
}

sub get_hot_water_meter_number {
    my $user_index = shift;

    ## no critic (ProhibitParensWithBuiltins)
    return sprintf( "$HOT_WATER_METER_NUMBER_PREFIX%05d", $user_index );
}

sub get_appartment_number {
    my $user_index = shift;

    return $user_index;
}

sub get_cold_water_consumption {
    my $user_index = shift;
    my $month      = shift;

    return ( $user_index + $month ) * $COLD_WATER_AMOUNT_FACOR;
}

sub get_hot_water_consumption {
    my $user_index = shift;
    my $month      = shift;

    return ( $user_index + $month ) * $HOT_WATER_AMOUNT_FACOR;
}

sub get_metering_passing_day {
    return $METERING_PASSING_DAY;
}

sub get_email {
    my $user_index = shift;

    return get_username($user_index) . q{@} . $EMAIL_DOMAIN;
}

1;
