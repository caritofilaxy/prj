package Meter::Sessions;

#===============================================================================
#     REVISION:  $Id: Sessions.pm 40 2011-07-08 11:09:28Z xdr.box@gmail.com $
#  DESCRIPTION:  Class::DBI wrapper for 'sessions' table
#===============================================================================

use strict;
use warnings;

use base qw(Meter::DBI);

use Readonly;
Readonly our $VERSION => qw($Revision: 40 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use Meter::Utils qw(
    inflate_iso8601_datetime
    deflate_iso8601_datetime
);

sub init_table {
    my $class = shift;

    __PACKAGE__->set_up_table('sessions');

    __PACKAGE__->has_a( user_id => 'Meter::Users' );

    __PACKAGE__->has_a(
        last_activity_datetime => 'DateTime',
        inflate                => \&inflate_iso8601_datetime,
        deflate                => \&deflate_iso8601_datetime,
    );

    ## no critic (ProhibitEnumeratedClasses)
    __PACKAGE__->constrain_column( session_id => qr/\A[a-zA-Z0-9]+\z/xms );

    return;
}

1;
