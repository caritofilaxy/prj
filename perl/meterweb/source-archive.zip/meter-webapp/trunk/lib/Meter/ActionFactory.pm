package Meter::ActionFactory;

#===============================================================================
#     REVISION:  $Id: ActionFactory.pm 93 2011-07-19 09:22:21Z xdr.box@gmail.com $
#  DESCRIPTION:  Create Meter::Action::* class depending on action name parameter
#===============================================================================

use strict;
use warnings;

use Readonly;
Readonly our $VERSION => qw($Revision: 93 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use Meter::Log;

use Meter::Action::Welcome;
use Meter::Action::Login;
use Meter::Action::ShowMeterings;
use Meter::Action::Register;
use Meter::Action::Logout;
use Meter::Action::DeleteAccount;
use Meter::Action::AppartmentInfo;
use Meter::Action::DeleteMetering;
use Meter::Action::AddMetering;
use Meter::Action::FillBlank;
use Meter::Action::ChangePassword;
use Meter::Action::SetupNotifications;

use Meter::Utils qw(
    get_action_module_by_action_name
);

Readonly my $DEFAULT_ACTION_MODULE => 'Meter::Action::Welcome';

sub create {
    my $class  = shift;
    my $cgi    = shift;
    my $config = shift;

    my $logger = get_logger();

    my $action_name   = $cgi->param('action');
    my $action_module = get_action_module_by_action_name($action_name);

    if ( !$action_module ) {
        $action_module = $DEFAULT_ACTION_MODULE;

        if ($action_name) {
            $logger->warn(
                "User explicitly passed invalid action: '$action_name'");
        }
    }

    return $action_module->new( $cgi, $config );
}

1;
