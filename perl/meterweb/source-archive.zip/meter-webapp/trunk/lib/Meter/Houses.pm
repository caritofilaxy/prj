package Meter::Houses;

#===============================================================================
#     REVISION:  $Id: Houses.pm 18 2011-07-01 12:38:33Z xdr.box@gmail.com $
#  DESCRIPTION:  Class::DBI wrapper for 'houses' table
#===============================================================================

use strict;
use warnings;

use base qw(Meter::DBI);

use Readonly;
Readonly our $VERSION => qw($Revision: 18 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

use Meter::Regexp qw(
    $NOT_EMPTY_RE
);

sub init_table {
    my $class = shift;

    __PACKAGE__->set_up_table('houses');

    __PACKAGE__->has_many( appartments => 'Meter::Appartments' );

    __PACKAGE__->constrain_column( address => $NOT_EMPTY_RE );

    return;
}

1;
