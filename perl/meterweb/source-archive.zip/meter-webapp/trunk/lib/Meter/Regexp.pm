package Meter::Regexp;

#===============================================================================
#     REVISION:  $Id: Regexp.pm 18 2011-07-01 12:38:33Z xdr.box@gmail.com $
#  DESCRIPTION:  Commonly used regexps for column constraints
#===============================================================================

use strict;
use warnings;

use base qw(Exporter);

use Readonly;
Readonly our $VERSION => qw($Revision: 18 $) [1];

use English qw( -no_match_vars );

#use Smart::Comments;

our @EXPORT_OK = qw(
    $NOT_EMPTY_RE
    $FLAG_01_RE
);

Readonly our $NOT_EMPTY_RE => qr/\A.+\z/xms;

Readonly our $FLAG_01_RE => qr/\A[01]\z/xms;

1;
